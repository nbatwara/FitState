package com.coms309.group11;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CreateEvent extends AppCompatActivity {

    Spinner sport;
    EditText ET_title;
    EditText ET_location;
    EditText ET_date;
    EditText ET_time;
    String[] sports;

    String title;
    String sportString;
    String address;
    String date;
    String time;
    String location_x = "0";
    String location_y = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        ET_title = (EditText) findViewById(R.id.eventName);
        sport = (Spinner) findViewById(R.id.sportID);
        sports = new String[]{"Basketball", "Football", "Frisbee", "Soccer", "Volleyball"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, sports);
        sport.setAdapter(adapter);
        ET_location = (EditText) findViewById(R.id.locationID);
        ET_date = (EditText) findViewById(R.id.dateID);
        ET_time = (EditText) findViewById(R.id.timeID);
    }

    public void createEventButton(View view) {
        Toast.makeText(this, "Made it into createEventButton", Toast.LENGTH_LONG).show();
        title = ET_title.getText().toString();
        sportString = sport.getSelectedItem().toString();
        address = ET_location.getText().toString();
        date = ET_date.getText().toString();
        time = ET_time.getText().toString();

        CreateEventTask createEventTask = new CreateEventTask(title, sportString, address, date, time, getApplicationContext());
        createEventTask.execute((Void[]) null);
    }

    class CreateEventTask extends AsyncTask<Void, Void, Void> {
        private final String title;
        private final String sportString;
        private final String address;
        private final String date;
        private final String time;
        private Context applicationContext;

        public CreateEventTask(String title, String sportString, String address, String date, String time, Context applicationContext) {
            this.title = title;
            this.sportString = sportString;
            this.address = address;
            this.date = date;
            this.time = time;
            this.applicationContext = applicationContext;
        }

        @Override
        protected Void doInBackground(Void... params) {
            RequestQueue rq = Volley.newRequestQueue(applicationContext);
            StringRequest addEventRequest = new StringRequest(Request.Method.POST, "http://proj-309-11.cs.iastate.edu/addEvent.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response){
                  if(response.contains("Success")) {
                        HashMap<String,String> params = new HashMap<>();
                        params.put("title", title);
                        params.put("sport", sportString);
                        params.put("address", address);
                        params.put("date", date);
                        params.put("time", time);
                        params.put("location_x", location_x);
                        params.put("location_y", location_y);
                   }
                    Intent profileIntent = new Intent(CreateEvent.this, EventsFirstPage.class);
                    CreateEvent.this.startActivity(profileIntent);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    System.out.println("Event not created: " + error + "");
                    Log.d("Response: ", error.toString());
                }
            }){
                @Override
                protected Map<String,String> getParams(){
                    HashMap<String,String> params = new HashMap<>();
                    params.put("title", title);
                    params.put("sport", sportString);
                    params.put("address", address);
                    params.put("date", date);
                    params.put("time", time);
                    params.put("location_x", location_x);
                    params.put("location_y", location_y);
                    return params;
                }
            };
            rq.add(addEventRequest);
            return null;
        }
    }
}
