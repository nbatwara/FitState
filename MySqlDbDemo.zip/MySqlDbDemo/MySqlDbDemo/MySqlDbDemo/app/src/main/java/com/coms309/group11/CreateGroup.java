package com.coms309.group11;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class CreateGroup extends AppCompatActivity {

    Spinner group_type;
    Spinner max_size;
    EditText ET_name;
    EditText ET_description;
    Button createGroup;
    String[] group_options;
    String[] size_options;
    String name;
    String description;
    String group_sport_type;
    String max_group_size;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_group);

        group_type = (Spinner) findViewById(R.id.group_type_ID);
        max_size = (Spinner) findViewById(R.id.max_size);
        ET_name = (EditText) findViewById(R.id.groupName);
        ET_description = (EditText) findViewById(R.id.group_description);
        createGroup = (Button) findViewById(R.id.createButton);
        group_options = new String[] {"Basketball", "Football", "Frisbee", "Soccer", "Volleybal"};
        size_options = new String[] {"10", "20", "30", "40", "50"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, group_options);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, size_options);
        group_type.setAdapter(adapter);
        max_size.setAdapter(adapter1);

        createGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = ET_name.getText().toString();
                description = ET_description.getText().toString();
                group_sport_type = group_type.getSelectedItem().toString();
                max_group_size = max_size.getSelectedItem().toString();

                CreateGroupTask createGroupTask = new CreateGroupTask(name, group_sport_type, description, max_group_size ,getApplicationContext());
                createGroupTask.execute((Void[]) null);
            }
        });
    }

    class CreateGroupTask extends AsyncTask<Void, Void, Void> {
        private final String name;
        private final String sport_type;
        private final String description;
        private final String size;
        private Context applicationContext;

        public CreateGroupTask(String name, String sport_type, String description, String size, Context applicationContext) {
            this.name = name;
            this.sport_type = sport_type;
            this.description = description;
            this.size = size;
            this.applicationContext = applicationContext;
        }

        @Override
        protected Void doInBackground(Void... params) {
            RequestQueue rq = Volley.newRequestQueue(applicationContext);
            StringRequest addEventRequest = new StringRequest(Request.Method.POST, "http://proj-309-11.cs.iastate.edu/addGroup.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response){
                    if(response.contains("Success")) {
                        HashMap<String,String> params = new HashMap<>();
                        params.put("name", name);
                        params.put("sport", sport_type);
                        params.put("description", description);
                        params.put("size", size);
                        Toast.makeText(CreateGroup.this, "Successfully created Group.", Toast.LENGTH_LONG).show();
                        Intent profileIntent = new Intent(CreateGroup.this, FitGroups.class);
                        CreateGroup.this.startActivity(profileIntent);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    System.out.println("Group not created: " + error + "");
                    Log.d("Response: ", error.toString());
                }
            }){
                @Override
                protected Map<String,String> getParams(){
                    HashMap<String,String> params = new HashMap<>();
                    params.put("name", name);
                    params.put("sport", sport_type);
                    params.put("description", description);
                    params.put("size", size);
                    return params;
                }
            };
            rq.add(addEventRequest);
            return null;
        }
    }
}
