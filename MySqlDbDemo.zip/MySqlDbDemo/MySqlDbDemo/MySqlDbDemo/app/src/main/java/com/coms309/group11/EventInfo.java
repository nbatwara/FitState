package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class EventInfo extends AppCompatActivity {

    String name;
    TextView TV_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_info);

        Intent intent = getIntent();

        name = intent.getStringExtra("eventName");

        TV_name = (TextView) findViewById(R.id.eventName);
        TV_name.setText(name + " Info");
    }
}
