package com.coms309.group11;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class EventList extends ListActivity {

    String[] event_title = new String[30];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        GetEvents getEvents = new GetEvents(getApplicationContext());
        getEvents.execute((Void[]) null);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getListView().getContext(), android.R.layout.simple_list_item_1, event_title);
        getListView().setAdapter(adapter);

        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int itemPosition = position;
                String itemValue = (String) getListView().getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), "Position:" + itemPosition + " ListItem:" + itemValue, Toast.LENGTH_LONG).show();
                Intent info = new Intent(EventList.this, EventInfo.class);
                EventList.this.startActivity(info);
            }
        });
    }

    class GetEvents extends AsyncTask<Void, Void, Void> {
        private Context applicationContext;

        public GetEvents (Context applicationContext) {
            this.applicationContext = applicationContext;
        }

        @Override
        protected Void doInBackground(Void... params) {
            RequestQueue rq = Volley.newRequestQueue(applicationContext);
            JsonArrayRequest jsonObjectRequest = new JsonArrayRequest(Request.Method.GET, "http://proj-309-11.cs.iastate.edu/getEvents.php", null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    try {
                        for(int i = 0; i < response.length(); i++){
                            event_title[i] = response.getJSONObject(i).getString("title");
                        }

                    }catch (JSONException e){
                        Toast.makeText(EventList.this, "Catch here", Toast.LENGTH_LONG).show();
                        Log.e("Error", e.getMessage());
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(EventList.this, "Not getting data.", Toast.LENGTH_SHORT).show();
                    Log.d("Error", error.getMessage());
                }
            });
            rq.add(jsonObjectRequest);
            return null;
        }
    }
}
