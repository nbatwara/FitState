package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class EventsFirstPage extends AppCompatActivity {

    //private static boolean firstEvent = false;
    //public static ArrayList<String[]> global_events; //= new ArrayList<String[]>();
    //public static String[] global_single_event;// = new String[5];
    Globals g = Globals.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_first_page);
    }

    public void createEvent(View view){
        startActivity(new Intent(this, CreateEvent.class));
    }

    public void findEvent(View view){
        startActivity(new Intent(this, SearchEvent.class));
    }

    public void eventList(View view){
        startActivity(new Intent(this, EventList.class));
    }

    public void home(View view){
        startActivity(new Intent(this, HomePage.class));
    }
}
