package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class FinishedWorkout extends AppCompatActivity {

    String workout = "Finished ";
    String duration;
    TextView TV_workout;
    TextView TV_duration;
    EditText ET_user_reps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finished_workout);

        Intent intent = getIntent();

        workout += intent.getStringExtra("workout");
        duration = intent.getStringExtra("duration");

        TV_workout = (TextView) findViewById(R.id.finished_workout);
        TV_duration = (TextView) findViewById(R.id.finished_duration_time);
        ET_user_reps = (EditText) findViewById(R.id.user_reps);

        TV_workout.setText(workout);
        TV_duration.setText(duration);
    }

    public void finished(View view){
        Toast.makeText(this, "Great Job!", Toast.LENGTH_LONG).show();
        startActivity(new Intent(this, WorkoutSelect.class));
    }
}
