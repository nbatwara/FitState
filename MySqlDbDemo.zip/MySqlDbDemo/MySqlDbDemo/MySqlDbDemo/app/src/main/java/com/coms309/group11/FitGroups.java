package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class FitGroups extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fit_groups);
    }

    public void createGroup(View view){
        startActivity(new Intent(this, CreateGroup.class));
    }

    public void viewGroups(View view){
        startActivity(new Intent(this, GroupList.class));
    }

    public void home(View view){
        startActivity(new Intent(this, HomePage.class));
    }

    public void myGroup(View view){
        startActivity(new Intent(this, GroupsPage.class));
    }
}
