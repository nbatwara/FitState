package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class FitStats extends AppCompatActivity {

    TextView TV_distance;
    TextView TV_steps;
    TextView TV_calories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fit_stats);

        TV_distance = (TextView) findViewById(R.id.distance_data);
        TV_steps = (TextView) findViewById(R.id.steps_data);
        TV_calories = (TextView) findViewById(R.id.calories_data);
    }

    public void home(View view){
        startActivity(new Intent(this, HomePage.class));
    }

    public void reset(View view){
        //startActivity(new Intent(this, FitStats.class));
        TV_distance.setText("0 miles");
        TV_steps.setText("0 steps");
        TV_calories.setText("0 calories");

    }

    public void bmi(){
        startActivity(new Intent(this, BMI.class));
    }
}
