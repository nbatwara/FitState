package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Fitness extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fitness);
    }

    public void selectWorkout(View view){
        startActivity(new Intent(this, WorkoutSelect.class));
    }

    public void paceStart(View view){
        startActivity(new Intent(this, StartPace.class));
    }

    public void fitStats(View view){
        startActivity(new Intent(this, FitStats.class));
    }

    public void home(View view){
        startActivity(new Intent(this, HomePage.class));
    }
}
