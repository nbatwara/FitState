package com.coms309.group11;

import java.util.ArrayList;

/**
 * Created by Eli on 4/4/2016.
 */
public class Globals {
    private static Globals instance;
    private static String global_name;
    private static String global_username;
    private static String global_email;
    private static String global_password;
    private static String global_title;
    private static String global_sport;
    private static String global_address;
    private static String global_date;
    private static String global_time;
    private static boolean oneEvent = false;
    private static String[] global_single_event;
    private static ArrayList<String[]> global_events;

    private Globals(){}

    public void setName(String name){
        Globals.global_name = name;
    }

    public String getName(){
        return Globals.global_name;
    }

    public void setUsername(String username){
        Globals.global_username = username;
    }

    public String getUsername(){
        return Globals.global_username;
    }

    public void setEmail(String email){
        Globals.global_email = email;
    }

    public String getEmail(){
        return Globals.global_email;
    }

    public void setPassword(String password){
        Globals.global_password = password;
    }

    public String getPassword(){
        return Globals.global_password;
    }

    public void setTitle(String title){
        Globals.global_title = title;
    }

    public String getTitle(){
        return Globals.global_title;
    }

    public void setSport(String sport){
        Globals.global_sport = sport;
    }

    public String getSport(){
        return Globals.global_sport;
    }

    public void setAddress(String address){
        Globals.global_address = address;
    }

    public String getAddress(){
        return Globals.global_address;
    }

    public void setDate(String date){
        Globals.global_date = date;
    }

    public String getDate(){
        return Globals.global_date;
    }

    public void setTime(String time){
        Globals.global_time = time;
    }

    public String getTime(){
        return Globals.global_time;
    }

    public void setOneEvent(boolean set){
        Globals.oneEvent = set;
    }

    public boolean getOneEvent(){
        return Globals.oneEvent;
    }

    public void setSingleEvent(String title, String sport, String address, String date, String time){
        Globals.global_single_event[0] = title;
        Globals.global_single_event[1] = sport;
        Globals.global_single_event[2] = address;
        Globals.global_single_event[3] = date;
        Globals.global_single_event[4] = time;
    }

    public String[] getSingleEvent(){
        return Globals.global_single_event;
    }

    public void setEvents(String[] single_event){
        Globals.global_events.add(single_event);
    }

    public ArrayList<String[]> getEvents(){
        return Globals.global_events;
    }

    public static synchronized  Globals getInstance(){
        if(instance == null){
            instance = new Globals();
        }
        return instance;
    }
}
