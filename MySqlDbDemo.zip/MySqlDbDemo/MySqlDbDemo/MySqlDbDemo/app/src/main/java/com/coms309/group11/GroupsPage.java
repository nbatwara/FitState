package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class GroupsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groups_page);
    }

    public void home(View view){
        startActivity(new Intent(this, HomePage.class));
    }

    public void back(View view){
        startActivity(new Intent(this, FitGroups.class));
    }
}
