package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.Map;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

    }

    public void profilePage(View view){
        Intent profileIntent = new Intent(this, ProfilePage.class);
        this.startActivity(profileIntent);
    }

    public void userFitness(View view){
        startActivity(new Intent(this, Fitness.class));
    }

    public void userGroups(View view){
        startActivity(new Intent(this, FitGroups.class));
    }

    public void events(View view){
        startActivity(new Intent(this, EventsFirstPage.class));
    }

    public void messages(View view){
        startActivity(new Intent(this, GroupsPage.class));
    }

    public void menuSettings(View view){
        startActivity(new Intent(this, MenuSettings.class));
    }

    public void logout(View view){
        startActivity(new Intent(this, MainActivity.class));
    }
}
