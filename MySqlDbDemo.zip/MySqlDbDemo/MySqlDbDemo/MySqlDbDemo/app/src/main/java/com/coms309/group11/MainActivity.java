package com.coms309.group11;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends Activity{

    EditText ET_name;
    EditText ET_password;
    String login_name;
    String login_password;

    Globals g = Globals.getInstance();

    String username;
    String name;
    String password;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ET_name = (EditText)findViewById(R.id.user_name);
        ET_password = (EditText)findViewById(R.id.user_pass);

        username = g.getUsername();
       //name = Register.global_name;
        //email = Register.global_email;
        password = g.getPassword();
    }

    public void userReg(View view){
        startActivity(new Intent(this,Register.class));
    }

    public void userLogin(View view){
        login_name = ET_name.getText().toString();
        login_password = ET_password.getText().toString();

//        UserLoginTask userLoginTask = new UserLoginTask(login_name, login_password, getApplicationContext());
//        userLoginTask.execute((Void[]) null);
//        finish();
        if(login_name.equals(username) && login_password.equals(password)){
            Intent profileIntent = new Intent(MainActivity.this, HomePage.class);
           //profileIntent.putExtra("name", name);
            //profileIntent.putExtra("email", email);
            MainActivity.this.startActivity(profileIntent);
        }
        else{
            Toast.makeText(MainActivity.this, "Wrong username or password.", Toast.LENGTH_LONG).show();
            System.out.println("Wrong username or password");
        }

    }
//    class UserLoginTask extends AsyncTask<Void, Void, Void> {
//        private final String username;
//        private final String password;
//        //private final String email;
//        private Context applicationContext;
//
//        public UserLoginTask(String username, String password, Context applicationContext) {
//            this.username = username;
//            this.password = password;
//            //this.email = email;
//            this.applicationContext = applicationContext;
//        }
//
//        @Override
//        protected Void doInBackground(Void... params) {
//            RequestQueue rq = Volley.newRequestQueue(applicationContext);
//            StringRequest registerRequest = new StringRequest(Request.Method.POST, "http://proj-309-11.cs.iastate.edu/login.php", new Response.Listener<String>() {
//                @Override
//                public void onResponse(String response) {
//                    if(response.contains("Success")) {
//                        Toast.makeText(MainActivity.this, "Successfully logged in", Toast.LENGTH_LONG).show();
//                        HashMap<String,String> params = new HashMap<>();
//                        params.put("userName", username);
//                        params.put("password", password);
//                        //params.put("email", email);
//
//                        Intent profileIntent = new Intent(MainActivity.this, HomePage.class);
//                        MainActivity.this.startActivity(profileIntent);
//                    }
//                    else{
//                        Toast.makeText(MainActivity.this, "Wrong username or password", Toast.LENGTH_LONG).show();
//                        Intent tryAgain = new Intent(MainActivity.this, MainActivity.class);
//                        MainActivity.this.startActivity(tryAgain);
//                    }
//
//                }
//            }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    Toast.makeText(MainActivity.this, "Failed to Login", Toast.LENGTH_LONG).show();
//                    Log.d("Error here", error.getMessage());
//                }
//            }){
//                @Override
//                protected Map<String,String> getParams() {
//                    HashMap<String,String> params = new HashMap<>();
//                    params.put("userName", username);
//                    params.put("password", password);
//                    //params.put("email", email);
//                    return params;
//                }
//            };
//            rq.add(registerRequest);
//            return null;
//        }
//    }

}
