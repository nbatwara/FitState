package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ProfileEmail extends AppCompatActivity {

    String email;
    EditText ET_email;
    Globals g = Globals.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_email);

        email = g.getEmail();

        ET_email = (EditText) findViewById(R.id.editable_email);
        ET_email.setHint(email);
    }

    public void edit(View view){
        Intent returnToProfile = new Intent(this, ProfilePage.class);
        String edited_email = ET_email.getText().toString();
        g.setEmail(edited_email);
        this.startActivity(returnToProfile);
    }

    public void returnProfile(View view){
        startActivity(new Intent(this, ProfilePage.class));
    }
}
