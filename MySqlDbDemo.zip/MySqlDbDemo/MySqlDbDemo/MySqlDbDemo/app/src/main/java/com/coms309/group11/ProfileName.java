package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ProfileName extends AppCompatActivity {

    String name;
    //String email;
    EditText ET_name;
    Globals g = Globals.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_name);

//        Intent intent = getIntent();
//
//        name = intent.getStringExtra("name");
//        email = intent.getStringExtra("email");

        name = g.getName(); //Register.global_name;

        ET_name = (EditText) findViewById(R.id.editable_name);
        ET_name.setHint(name);
}

    public void edit(View view){
        Intent returnToProfile = new Intent(this, ProfilePage.class);
        String edited_name = ET_name.getText().toString();
        g.setName(edited_name);
        //Register.global_name = edited_name;
        //returnToProfile.putExtra("name", edited_name);
        //returnToProfile.putExtra("email", email);
        this.startActivity(returnToProfile);
    }

    public void returnProfile(View view){
        Intent returnToProfile = new Intent(this, ProfilePage.class);
        //returnToProfile.putExtra("name", name);
       // returnToProfile.putExtra("email", email);
        this.startActivity(returnToProfile);
    }

}
