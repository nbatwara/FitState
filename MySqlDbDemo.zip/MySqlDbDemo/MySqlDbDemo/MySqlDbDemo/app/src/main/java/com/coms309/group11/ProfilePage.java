package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class ProfilePage extends AppCompatActivity {

    TextView TV_username;
    TextView TV_email;
    String name = "Empty";
    String email = "Empty@gmail.com";
    //Globals g = Globals.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);


//        For use of hardcoding
//        Intent intent = getIntent();
//
//        name = intent.getStringExtra("name");
//        email = intent.getStringExtra("email");

       //name = g.getName(); //Register.global_name;
        //email = g.getEmail();

        TV_username = (TextView) findViewById(R.id.Name);
        TV_email= (TextView) findViewById(R.id.email);
        if(name.equals("") || email.equals("")){
            Toast.makeText(this, "No name or email passed", Toast.LENGTH_LONG).show();
        }
        else{
            TV_username.setText(name);
            TV_email.setText(email);
        }
    }

    public void userName(View view){

        Intent nameChangeIntent = new Intent(this, ProfileName.class);
        //nameChangeIntent.putExtra("name", name);
        //nameChangeIntent.putExtra("email", email);
        this.startActivity(nameChangeIntent);
    }

    public void userEmail(View view){
        startActivity(new Intent(this, ProfileEmail.class));
    }

    public void userAge(View view){
        startActivity(new Intent(this, ProfileAge.class));
    }

    public void userSex(View view){
        startActivity(new Intent(this, ProfileSex.class));
    }

    public void userHobbies(View view){
        startActivity(new Intent(this, ProfileHobbies.class));
    }

    public void userSettings(View view){
        startActivity(new Intent(this, ProfileSettings.class));
    }

    public void home(View view){
        Intent homeIntent = new Intent(this, HomePage.class);
        //homeIntent.putExtra("name", name);
        //homeIntent.putExtra("email", email);
        this.startActivity(homeIntent);
    }
}
