package com.coms309.group11;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;


public class Register extends Activity {

    EditText ET_name;
    EditText ET_userName;
    EditText ET_password;
    EditText ET_email;
    String name;
    String userName;
    String password;
    String email;
    //For use of hardcoding
    //public static String global_name;
    //public static String global_username;
    //public static String global_email;
    //public static String global_password;
    Globals g = Globals.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
        ET_name = (EditText) findViewById(R.id.name);
        ET_userName = (EditText) findViewById(R.id.new_user_name);
        ET_password = (EditText) findViewById(R.id.new_user_pass);
        ET_email = (EditText) findViewById(R.id.new_user_email);
    }

    public void userReg(View view) {
        name = ET_name.getText().toString();
        userName = ET_userName.getText().toString();
        password = ET_password.getText().toString();
        email = ET_email.getText().toString();
        //For use of hardcoding
        g.setEmail(email);
        g.setName(name);
        g.setUsername(userName);
        g.setPassword(password);
        //For use of hardcoding
        Intent profileIntent = new Intent(Register.this, MainActivity.class);
        //profileIntent.putExtra("name", name);
        //profileIntent.putExtra("username", userName);
        //profileIntent.putExtra("email", email);
        // profileIntent.putExtra("password", password);
        Register.this.startActivity(profileIntent);


        //For use of integration
        //UserRegisterTask userRegisterTask = new UserRegisterTask(userName, password, email, getApplicationContext());
        //userRegisterTask.execute((Void[]) null);
       // finish();
    }


//    class UserRegisterTask extends AsyncTask<Void, Void, Void> {
//        private final String username;
//        private final String password;
//        private final String email;
//        private Context applicationContext;
//
//        public UserRegisterTask(String username, String password, String email, Context applicationContext) {
//            this.username = username;
//            this.password = password;
//            this.email = email;
//            this.applicationContext = applicationContext;
//        }
//
//        @Override
//        protected Void doInBackground(Void... params) {
//            RequestQueue rq = Volley.newRequestQueue(applicationContext);
//            StringRequest registerRequest = new StringRequest(Request.Method.POST, "http://proj-309-11.cs.iastate.edu/Demo/register.php", new Response.Listener<String>() {
//                @Override
//                public void onResponse(String response) {
//                    if(response.contains("Success")) {
//                       Toast.makeText(Register.this, "Successfully created new user", Toast.LENGTH_LONG).show();
//                        HashMap<String,String> params = new HashMap<>();
//                        params.put("username", username);
//                        params.put("password", password);
//                        params.put("email", email);
//
//                        Intent profileIntent = new Intent(Register.this, MainActivity.class);
//                        Register.this.startActivity(profileIntent);
//                    }
//                    else{
//                        Toast.makeText(Register.this, "Failed to Register User", Toast.LENGTH_LONG).show();
//                        Intent tryAgain = new Intent(Register.this, Register.class);
//                        Register.this.startActivity(tryAgain);
//                    }
//                }
//            }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    Toast.makeText(Register.this, "Failed to Register User", Toast.LENGTH_LONG).show();
//                    Log.d("Error here", error.getMessage());
//                }
//            }){
//                @Override
//                protected Map<String,String> getParams() {
//                    HashMap<String,String> params = new HashMap<>();
//                    params.put("username", username);
//                    params.put("password", password);
//                    params.put("email", email);
//                    return params;
//                }
//            };
//            rq.add(registerRequest);
//            return null;
//        }
//    }
}

