package com.coms309.group11;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class SearchEvent extends AppCompatActivity {

    String test;
    Button test_button;
    TextView TV_test;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_event);

        TV_test = (TextView) findViewById(R.id.test1);
        test_button = (Button) findViewById(R.id.testButton);
        test_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GetEvents getEvents = new GetEvents(SearchEvent.this);
                getEvents.execute((Void[]) null);
                //TV_test.setText(test);
            }
        });


    }

    class GetEvents extends AsyncTask<Void, Void, Void> {
        //private final String username;
        //private final String password;
        //private final String email;
        //TextView textView;
        private Context applicationContext;

        public GetEvents (Context applicationContext) {
            //this.username = username;
            //this.password = password;
            //this.email = email;
            this.applicationContext = applicationContext;
        }

        @Override
        protected Void doInBackground(Void... params) {
            RequestQueue rq = Volley.newRequestQueue(applicationContext);
            JsonArrayRequest jsonObjectRequest = new JsonArrayRequest(Request.Method.GET, "http://proj-309-11.cs.iastate.edu/getEvents.php", null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                   try {

                       test = response.getJSONObject(0).getString("title");
                       TV_test.setText(test);

                   }catch (JSONException e){
                       Toast.makeText(SearchEvent.this, "Catch here", Toast.LENGTH_LONG).show();
                       Log.e("Error", e.getMessage());
                   }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(SearchEvent.this, "Not getting data.", Toast.LENGTH_SHORT).show();
                    Log.d("Error", error.getMessage());
                }
            });
            rq.add(jsonObjectRequest);
            return null;
        }
    }
}
