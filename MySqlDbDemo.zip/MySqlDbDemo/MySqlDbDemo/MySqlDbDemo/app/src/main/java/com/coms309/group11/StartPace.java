package com.coms309.group11;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class StartPace extends AppCompatActivity implements SensorEventListener {

    private SensorManager stepCounter;
    private TextView count;
    private TextView time;
    boolean counting;
    Button start_button;
    Button stop_button;
    Button start_time;
    Button reset_time;
    //Button home;
    long starttime = 0L;
    long timeInMilliseconds = 0L;
    long timeSwapBuff = 0L;
    long updatetime = 0L;
    int t = 1;
    int secs = 0;
    int mins = 0;
    int milliseconds = 0;
    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_pace);

        counting = false;
        start_button = (Button) findViewById(R.id.start_count);
        stop_button = (Button) findViewById(R.id.stop_count);
        start_time = (Button) findViewById(R.id.start_timer);
        reset_time = (Button) findViewById(R.id.reset_timer);
       //home = (Button) findViewById(R.id.home);
        count = (TextView) findViewById(R.id.stepsCounted);
        time = (TextView) findViewById(R.id.stopwatch);
        stepCounter = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        start_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onResume();
            }
        });
        //On Stop maybe send the steps to database. overwrite if necessary for Fit Stats
        stop_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPause();
            }
        });

        start_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(t==1){
                    start_time.setText("Stop Timer");
                    starttime = SystemClock.uptimeMillis();
                    handler.postDelayed(updateTimer,0);
                    t = 0;
                }
                else{
                    start_time.setText("Start Timer");
                    timeSwapBuff += timeInMilliseconds;
                    handler.removeCallbacks(updateTimer);
                    t = 1;
                }
            }
        });

        reset_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                starttime = 0L;
                timeInMilliseconds = 0L;
                timeSwapBuff = 0L;
                updatetime = 0L;
                t = 1;
                secs = 0;
                mins = 0;
                milliseconds = 0;
                start_time.setText("Start Timer");
                handler.removeCallbacks(updateTimer);
                time.setText("00:00:00");
            }
        });
    }

    public void home(View view){
        startActivity(new Intent(this, HomePage.class));
    }

    public Runnable updateTimer = new Runnable(){
        public void run(){
            timeInMilliseconds = SystemClock.uptimeMillis() - starttime;
            updatetime = timeSwapBuff + timeInMilliseconds;
            secs = (int) (updatetime / 1000);
            mins = secs / 60;
            secs = secs % 60;
            milliseconds = (int) (updatetime % 1000);
            time.setText("" + mins + ":" + String.format("%02d", secs) + ":" + String.format("%02d", milliseconds));
            handler.postDelayed(this,0);
        }};

    @Override
    protected void onResume(){
        super.onResume();
        counting = true;
        Sensor countSensor = stepCounter.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if(countSensor != null){
            //Toast.makeText(this, "Count sensor not available.", Toast.LENGTH_LONG).show();
            stepCounter.registerListener(this, countSensor, SensorManager.SENSOR_DELAY_UI);
        }
        else{
            Toast.makeText(this, "Count sensor not available.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onPause(){
        super.onPause();
        counting = false;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(counting) {
            count.setText((String.valueOf(event.values[0])));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
