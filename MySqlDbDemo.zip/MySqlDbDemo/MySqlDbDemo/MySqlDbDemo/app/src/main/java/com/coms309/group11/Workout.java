package com.coms309.group11;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.sql.Time;
import java.util.concurrent.TimeUnit;

//@TargetApi(Build.VERSION_CODES.GINGERBREAD)
//@SuppressLint("NewApi")

public class Workout extends AppCompatActivity {

    Button begin;
    Button cancel;
    Button show_video;
    TextView timer_count;
    TextView workout_name;
    String workout;
    String duration;
    String display_duration;
    String[] workouts;
    int minutes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        Intent intent = getIntent();

        workout = intent.getStringExtra("workout");
        duration = intent.getStringExtra("duration");
        minutes = Integer.parseInt(duration);
        if(minutes < 10){
            duration = "0" + duration;
        }

        workouts = new String[] {"Sit-Ups", "Push-Ups", "Pull-Ups", "Burpees", "Ab Twists"};
        display_duration = "00:" + duration + ":00";
        begin = (Button) findViewById(R.id.begin_button);
        cancel = (Button) findViewById(R.id.cancel_workout);
        show_video = (Button) findViewById(R.id.show_workout_video);
        timer_count = (TextView) findViewById(R.id.countDown);
        workout_name = (TextView) findViewById(R.id.workout_name);
        timer_count.setText(display_duration);
        workout_name.setText(workout);
        final CounterClass timer = new CounterClass(60000*minutes,1000);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent profileIntent = new Intent(Workout.this, WorkoutSelect.class);
                Toast.makeText(Workout.this, "Awww... Come on now!", Toast.LENGTH_SHORT).show();
                Workout.this.startActivity(profileIntent);
            }
        });

        begin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.start();
            }
        });

        show_video.setOnClickListener(new View.OnClickListener() {
            int workout_number;
            String workout_url;

            @Override
            public void onClick(View v) {
                for(int i = 0; i < workouts.length; i++){
                    if(workout.equals(workouts[i])){
                        workout_number = i;
                    }
                }
                switch(workout_number) {
                    case 0: //Sit-ups
                        workout_url = "1fbU_MkV7NE";
                        break;
                    case 1: //Push-ups
                        workout_url = "rtsp://r19---sn-vgqs7n76.googlevideo.com/Cj0LENy73wIaNAmSrN_8DymiFRMYDSANFC3mWgFXMOCoAUIASARglJeM9JXn4eNWigELbk9EV1dkTWgtNzQM/D193F873A65D99AC4D90D5643C64B2B8B833E08B.10A75727426162983A20CBE0C80EAB12109047C2/yt6/1/video.3gp";
                        break;
                    case 2: //Pull-ups
                        workout_url = "rtsp://r7---sn-vgqsens7.googlevideo.com/Cj0LENy73wIaNAltn8JpsunPEhMYDSANFC0LWwFXMOCoAUIASARglJeM9JXn4eNWigELbk9EV1dkTWgtNzQM/04048376C0399E6483CFEB6839DF9B1B1FCA665E.B0170D4E8E0F79A0B62F81D18735635B77E386EC/yt6/1/video.3gp";
                        break;
                    case 3: //Burpees
                        workout_url = "rtsp://r1---sn-vgqs7ney.googlevideo.com/Cj0LENy73wIaNAlFqaygZRgbVBMYDSANFC0kWwFXMOCoAUIASARglJeM9JXn4eNWigELbk9EV1dkTWgtNzQM/6386C016ACCB2E9FF2F284C2FC89DDEA44DC4391.58A10872BB53E84808AE127D4B4C482A57CAC563/yt6/1/video.3gp";
                        break;
                    case 4: //Ab Twists
                        workout_url = "rtsp://r16---sn-vgqsenel.googlevideo.com/Cj0LENy73wIaNAm27Pzd3-G7dhMYDSANFC1TWwFXMOCoAUIASARglJeM9JXn4eNWigELbk9EV1dkTWgtNzQM/80A48B4928D017AFE248E8BCD861FFA8E6BF542D.3759DD938846347EC9794096DEDFF6418F06CED4/yt6/1/video.3gp";//https://www.youtube.com/watch?v=9FGilxCbdz8";
                        break;
                }
                Intent workoutVideoIntent = new Intent(Workout.this, WorkoutVideo.class);
                workoutVideoIntent.putExtra("workoutURL", workout_url);
                workoutVideoIntent.putExtra("workout", workout);
                workoutVideoIntent.putExtra("duration", duration);
                Workout.this.startActivity(workoutVideoIntent);
            }
        });
    }

    //@TargetApi(Build.VERSION_CODES.GINGERBREAD)
    //@SuppressLint("NewApi")
    public class CounterClass extends CountDownTimer{

        public CounterClass(long millisInFuture, long countDownInterval){
            super(millisInFuture, countDownInterval);
        }
        @Override
        public void onFinish(){
            Intent profileIntent = new Intent(Workout.this, FinishedWorkout.class);
            profileIntent.putExtra("workout", workout);
            profileIntent.putExtra("duration", display_duration);
            Workout.this.startActivity(profileIntent);
        }
        //@SuppressLint("NewApi")
        //@TargetApi(Build.VERSION_CODES.GINGERBREAD)
        @Override
        public void onTick(long millisUntilFinished){
            long millis = millisUntilFinished;
            String hms = String.format("%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millis),
                    TimeUnit.MILLISECONDS.toMinutes(millis) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millis)),
                    TimeUnit.MILLISECONDS.toSeconds(millis) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millis)));
            timer_count.setText(hms);
        }
    }
}
