package com.coms309.group11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class WorkoutSelect extends AppCompatActivity {

    Spinner workout;
    Spinner SP_duration;
    String[] workouts;
    String[] duration;
    String selected_Workout;
    String selected_Duration;
   // String getSelected_Duration_Display;
   // int int_duration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_select);

        workout= (Spinner) findViewById(R.id.workout_spinner);
        SP_duration = (Spinner) findViewById(R.id.duration_spinner);
        workouts = new String[] {"Sit-Ups", "Push-Ups", "Pull-Ups", "Burpees", "Ab Twists"};
        duration = new String[] {"1", "2", "3", "5", "10", "15"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, workouts);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, duration);
        workout.setAdapter(adapter);
        SP_duration.setAdapter(adapter1);
    }

    public void selectButton(View view){
        selected_Workout = workout.getSelectedItem().toString();
        selected_Duration = SP_duration.getSelectedItem().toString();
        //int_duration = Integer.parseInt(selected_Duration);
//        if(int_duration < 10){
//
//        }
        Intent profileIntent = new Intent(WorkoutSelect.this, Workout.class);
        profileIntent.putExtra("workout", selected_Workout);
        profileIntent.putExtra("duration", selected_Duration);
        WorkoutSelect.this.startActivity(profileIntent);
    }

    public void back(View view){
        startActivity(new Intent(this, Fitness.class));
    }
}
