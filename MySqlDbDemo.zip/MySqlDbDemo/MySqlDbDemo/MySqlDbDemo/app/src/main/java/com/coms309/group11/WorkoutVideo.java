package com.coms309.group11;

import android.app.ProgressDialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.MediaController;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class WorkoutVideo extends YouTubeBaseActivity {

    Button back_to_workout;
    Button play_button;
    //ProgressDialog progressDialog;
    YouTubePlayerView workout_video;
    YouTubePlayer.OnInitializedListener onInitializedListener;
    String workout;
    String duration;
    String workoutURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_video);

        Intent intent = getIntent();

        workoutURL = intent.getStringExtra("workoutURL");
        workout = intent.getStringExtra("workout");
        duration = intent.getStringExtra("duration");

        back_to_workout = (Button) findViewById(R.id.begin_workout_button);
        play_button = (Button) findViewById(R.id.play_button);
        workout_video = (YouTubePlayerView) findViewById(R.id.Youtube_view);
        onInitializedListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
                youTubePlayer.loadVideo("1fbU_MkV7NE");
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
                Toast.makeText(WorkoutVideo.this, "Failed to Load Video", Toast.LENGTH_LONG).show();
            }
        };

        back_to_workout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent return_to_workout = new Intent(WorkoutVideo.this, Workout.class);
                return_to_workout.putExtra("workout", workout);
                return_to_workout.putExtra("duration", duration);
                WorkoutVideo.this.startActivity(return_to_workout);
            }
        });

        play_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                workout_video.initialize("AIzaSyCVr26jYYWSrG6FaHcY0gcQ9B0AzHuMqLA", onInitializedListener);
            }
        });

    }
}
